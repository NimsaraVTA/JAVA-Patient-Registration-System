-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2021 at 07:10 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oncoclinicproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `D_Name` varchar(20) NOT NULL,
  `D_Contact` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`D_Name`, `D_Contact`) VALUES
(' B', ' 333');

-- --------------------------------------------------------

--
-- Table structure for table `patientdata1`
--

CREATE TABLE `patientdata1` (
  `hospital` varchar(100) DEFAULT NULL,
  `file_no` varchar(15) DEFAULT NULL,
  `consultant` varchar(100) DEFAULT NULL,
  `d_of_reg` date DEFAULT NULL,
  `f_name` varchar(100) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `d_of_birth` date DEFAULT NULL,
  `sex` varchar(7) DEFAULT NULL,
  `id_no` varchar(100) DEFAULT NULL,
  `p_address` varchar(100) DEFAULT NULL,
  `d_address` varchar(100) DEFAULT NULL,
  `dis` varchar(100) DEFAULT NULL,
  `dn_divi` varchar(100) DEFAULT NULL,
  `gn_divi` varchar(100) DEFAULT NULL,
  `t_no` varchar(10) DEFAULT NULL,
  `m_no` varchar(10) DEFAULT NULL,
  `job` varchar(100) DEFAULT NULL,
  `ethic` varchar(100) DEFAULT NULL,
  `reli` varchar(100) DEFAULT NULL,
  `marital` varchar(100) DEFAULT NULL,
  `suffer` varchar(100) DEFAULT NULL,
  `rela` varchar(100) DEFAULT NULL,
  `site_can` varchar(100) DEFAULT NULL,
  `h_reffer` varchar(100) DEFAULT NULL,
  `topo` varchar(100) DEFAULT NULL,
  `morp` varchar(100) DEFAULT NULL,
  `icdo_c` varchar(100) DEFAULT NULL,
  `icdo_code` varchar(100) DEFAULT NULL,
  `behaviour` varchar(100) DEFAULT NULL,
  `defferentiation` varchar(100) DEFAULT NULL,
  `valid` varchar(100) DEFAULT NULL,
  `laterality` varchar(100) DEFAULT NULL,
  `dod` varchar(100) DEFAULT NULL,
  `tnm` varchar(100) DEFAULT NULL,
  `stage` varchar(100) DEFAULT NULL,
  `sit` varchar(100) DEFAULT NULL,
  `his` varchar(100) DEFAULT NULL,
  `dodia` varchar(100) DEFAULT NULL,
  `re_site` varchar(100) DEFAULT NULL,
  `dor` varchar(100) DEFAULT NULL,
  `treat` varchar(100) DEFAULT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `dlc` varchar(100) DEFAULT NULL,
  `re_to` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patientdata1`
--

INSERT INTO `patientdata1` (`hospital`, `file_no`, `consultant`, `d_of_reg`, `f_name`, `age`, `d_of_birth`, `sex`, `id_no`, `p_address`, `d_address`, `dis`, `dn_divi`, `gn_divi`, `t_no`, `m_no`, `job`, `ethic`, `reli`, `marital`, `suffer`, `rela`, `site_can`, `h_reffer`, `topo`, `morp`, `icdo_c`, `icdo_code`, `behaviour`, `defferentiation`, `valid`, `laterality`, `dod`, `tnm`, `stage`, `sit`, `his`, `dodia`, `re_site`, `dor`, `treat`, `remark`, `dlc`, `re_to`, `name`) VALUES
('Kurunegala', '12k', 'Mis.Anu', '1998-08-13', 'Thathsarani Nimsara Narasinghe Bandara', '22', '1998-08-13', 'Female', 'xxxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'Sinhala', 'Buddihist', 'Unmarried', 'Select', 'xxx', 'xxx', 'xxxx', 'xxx', 'xxx', 'xxx', 'xxx', '(0) Benign', '(1) Moderate/Intermediate Grade', '2. Clinical only', '(0) Not a Paired Site', 'xxx', 'T', '9', 'xxx', 'xxx', 'xxx', 'xxx', 'xxx', 'Cancer Directed Surgery', 'xxx', 'xxx', 'xxx', 'xxx'),
(' Kandy', ' 13k', ' xxx', '2014-10-11', ' aaaaaaaaaaaaaaaa', ' 23', '2014-10-11', 'Female', ' cccc', ' ccccc', ' cccc', ' ccccc', ' cccc', ' ccc', ' cccc', ' ', ' cccc', 'Sinhala', 'Buddihist', 'Unmarried', 'Select', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '(0) Benign', '(1) Moderate/Intermediate Grade', '2. Clinical only', '(0) Not a Paired Site', ' ', 'T', ' ', ' ', ' ', ' ', ' ', ' ', 'Cancer Directed Surgery', ' ', ' ', ' ', ' '),
('Kurunegala123', '11000', 'Mrs. Nalani', '2021-01-23', 'xxxxx', '21', '2021-01-23', 'Female', '', 'xxxxxx', 'xxxxxx', '', '', '', '', '', '', 'Select', 'Select', 'Select', 'Select', '', '', '', '', '', '', '', 'Behaviour', 'Deferrentiation', 'Most Valid Basis of Diagnosis', 'Laterality', '', 'Select', '', '', '', '', '', '', 'Treatment', '', '', '', ''),
('Kandy', '1200', 'Mrs. nalani', '2021-01-08', '', '', '2021-01-08', 'Select', '', '', '', '', '', '', '', '', '', 'Select', 'Select', 'Select', 'Select', '', '', '', '', '', '', '', 'Behaviour', 'Deferrentiation', 'Most Valid Basis of Diagnosis', 'Laterality', '', 'Select', '', '', '', '', '', '', 'Treatment', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `patientdata2`
--

CREATE TABLE `patientdata2` (
  `hospital` varchar(100) DEFAULT NULL,
  `file_no` varchar(15) DEFAULT NULL,
  `consultant` varchar(100) DEFAULT NULL,
  `d_of_reg` date DEFAULT NULL,
  `f_name` varchar(100) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `d_of_birth` date DEFAULT NULL,
  `sex` varchar(7) DEFAULT NULL,
  `id_no` varchar(100) DEFAULT NULL,
  `p_address` varchar(100) DEFAULT NULL,
  `d_address` varchar(100) DEFAULT NULL,
  `dis` varchar(100) DEFAULT NULL,
  `dn_divi` varchar(100) DEFAULT NULL,
  `gn_divi` varchar(100) DEFAULT NULL,
  `t_no` varchar(10) DEFAULT NULL,
  `m_no` varchar(10) DEFAULT NULL,
  `job` varchar(100) DEFAULT NULL,
  `ethic` varchar(100) DEFAULT NULL,
  `reli` varchar(100) DEFAULT NULL,
  `marital` varchar(100) DEFAULT NULL,
  `suffer` varchar(100) DEFAULT NULL,
  `rela` varchar(100) DEFAULT NULL,
  `site_can` varchar(100) DEFAULT NULL,
  `h_reffer` varchar(100) DEFAULT NULL,
  `topo` varchar(100) DEFAULT NULL,
  `morp` varchar(100) DEFAULT NULL,
  `icdo_c` varchar(100) DEFAULT NULL,
  `icdo_code` varchar(100) DEFAULT NULL,
  `behaviour` varchar(100) DEFAULT NULL,
  `defferentiation` varchar(100) DEFAULT NULL,
  `valid` varchar(100) DEFAULT NULL,
  `laterality` varchar(100) DEFAULT NULL,
  `dod` varchar(100) DEFAULT NULL,
  `tnm` varchar(100) DEFAULT NULL,
  `stage` varchar(100) DEFAULT NULL,
  `sit` varchar(100) DEFAULT NULL,
  `his` varchar(100) DEFAULT NULL,
  `dodia` varchar(100) DEFAULT NULL,
  `re_site` varchar(100) DEFAULT NULL,
  `dor` varchar(100) DEFAULT NULL,
  `treat` varchar(100) DEFAULT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `dlc` varchar(100) DEFAULT NULL,
  `re_to` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patientdata2`
--

INSERT INTO `patientdata2` (`hospital`, `file_no`, `consultant`, `d_of_reg`, `f_name`, `age`, `d_of_birth`, `sex`, `id_no`, `p_address`, `d_address`, `dis`, `dn_divi`, `gn_divi`, `t_no`, `m_no`, `job`, `ethic`, `reli`, `marital`, `suffer`, `rela`, `site_can`, `h_reffer`, `topo`, `morp`, `icdo_c`, `icdo_code`, `behaviour`, `defferentiation`, `valid`, `laterality`, `dod`, `tnm`, `stage`, `sit`, `his`, `dodia`, `re_site`, `dor`, `treat`, `remark`, `dlc`, `re_to`, `name`) VALUES
('Kurunegala', '12k', 'Mis.Anu', '1998-08-13', 'Thathsarani Nimsara Narasinghe ', '22', '1998-08-13', 'Female', 'xxxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'Sinhala', 'Buddihist', 'Unmarried', 'Select', 'xxx', 'xxx', 'xxxx', 'xxx', 'xxx', 'xxx', 'xxx', '(0) Benign', '(1) Moderate/Intermediate Grade', '2. Clinical only', '(0) Not a Paired Site', 'xxx', 'T', '9', 'xxx', 'xxx', 'xxx', 'xxx', 'xxx', 'Cancer Directed Surgery', 'xxx', 'xxx', 'xxx', 'xxx'),
(' Kandy', ' 13k', ' xxx', '2014-10-11', ' aaaaaaaaaaaaaaaa', ' 23', '2014-10-11', 'Female', ' cccc', ' ccccc', ' cccc', ' ccccc', ' cccc', ' ccc', ' cccc', ' ', ' cccc', 'Sinhala', 'Buddihist', 'Unmarried', 'Select', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '(0) Benign', '(1) Moderate/Intermediate Grade', '2. Clinical only', '(0) Not a Paired Site', ' ', 'T', ' ', ' ', ' ', ' ', ' ', ' ', 'Cancer Directed Surgery', ' ', ' ', ' ', ' ');

-- --------------------------------------------------------

--
-- Table structure for table `patientdata3`
--

CREATE TABLE `patientdata3` (
  `hospital` varchar(100) DEFAULT NULL,
  `file_no` varchar(15) DEFAULT NULL,
  `consultant` varchar(100) DEFAULT NULL,
  `d_of_reg` date DEFAULT NULL,
  `f_name` varchar(100) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `d_of_birth` date DEFAULT NULL,
  `sex` varchar(7) DEFAULT NULL,
  `id_no` varchar(100) DEFAULT NULL,
  `p_address` varchar(100) DEFAULT NULL,
  `d_address` varchar(100) DEFAULT NULL,
  `dis` varchar(100) DEFAULT NULL,
  `dn_divi` varchar(100) DEFAULT NULL,
  `gn_divi` varchar(100) DEFAULT NULL,
  `t_no` varchar(10) DEFAULT NULL,
  `m_no` varchar(10) DEFAULT NULL,
  `job` varchar(100) DEFAULT NULL,
  `ethic` varchar(100) DEFAULT NULL,
  `reli` varchar(100) DEFAULT NULL,
  `marital` varchar(100) DEFAULT NULL,
  `suffer` varchar(100) DEFAULT NULL,
  `rela` varchar(100) DEFAULT NULL,
  `site_can` varchar(100) DEFAULT NULL,
  `h_reffer` varchar(100) DEFAULT NULL,
  `topo` varchar(100) DEFAULT NULL,
  `morp` varchar(100) DEFAULT NULL,
  `icdo_c` varchar(100) DEFAULT NULL,
  `icdo_code` varchar(100) DEFAULT NULL,
  `behaviour` varchar(100) DEFAULT NULL,
  `defferentiation` varchar(100) DEFAULT NULL,
  `valid` varchar(100) DEFAULT NULL,
  `laterality` varchar(100) DEFAULT NULL,
  `dod` varchar(100) DEFAULT NULL,
  `tnm` varchar(100) DEFAULT NULL,
  `stage` varchar(100) DEFAULT NULL,
  `sit` varchar(100) DEFAULT NULL,
  `his` varchar(100) DEFAULT NULL,
  `dodia` varchar(100) DEFAULT NULL,
  `re_site` varchar(100) DEFAULT NULL,
  `dor` varchar(100) DEFAULT NULL,
  `treat` varchar(100) DEFAULT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `dlc` varchar(100) DEFAULT NULL,
  `re_to` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patientdata3`
--

INSERT INTO `patientdata3` (`hospital`, `file_no`, `consultant`, `d_of_reg`, `f_name`, `age`, `d_of_birth`, `sex`, `id_no`, `p_address`, `d_address`, `dis`, `dn_divi`, `gn_divi`, `t_no`, `m_no`, `job`, `ethic`, `reli`, `marital`, `suffer`, `rela`, `site_can`, `h_reffer`, `topo`, `morp`, `icdo_c`, `icdo_code`, `behaviour`, `defferentiation`, `valid`, `laterality`, `dod`, `tnm`, `stage`, `sit`, `his`, `dodia`, `re_site`, `dor`, `treat`, `remark`, `dlc`, `re_to`, `name`) VALUES
('Kurunegala', '12k', 'Mis.Anu', '1998-08-13', 'Thathsarani Nimsara Narasinghe Bandara', '22', '1998-08-13', 'Female', 'xxxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'Sinhala', 'Buddihist', 'Unmarried', 'Select', 'xxx', 'xxx', 'xxxx', 'xxx', 'xxx', 'xxx', 'xxx', '(0) Benign', '(1) Moderate/Intermediate Grade', '2. Clinical only', '(0) Not a Paired Site', 'xxx', 'T', '9', 'xxx', 'xxx', 'xxx', 'xxx', 'xxx', 'Cancer Directed Surgery', 'xxx', 'xxx', 'xxx', 'xxx'),
(' Kandy', ' 13k', ' xxx', '2014-10-11', ' aaaaaaaaaaaaaaaa', ' 23', '2014-10-11', 'Female', ' cccc', ' ccccc', ' cccc', ' ccccc', ' cccc', ' ccc', ' cccc', ' ', ' cccc', 'Sinhala', 'Buddihist', 'Unmarried', 'Select', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '(0) Benign', '(1) Moderate/Intermediate Grade', '2. Clinical only', '(0) Not a Paired Site', ' ', 'T', ' ', ' ', ' ', ' ', ' ', ' ', 'Cancer Directed Surgery', ' ', ' ', ' ', ' ');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(10) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `The_image` blob DEFAULT NULL,
  `clinic` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `username`, `The_image`, `clinic`) VALUES
(123, 'aaa', 0x47494638396108015c00f10000ffffff000000ff00000000002c0000000008015c000002fe848fa96b210f63504e30f4829e697b4d81cd1772c0e7955ba992a379a06dfaae0c6a9fa24e5ffe0f0cc63c8f17eb97c90d71479ed2587321649ddd92ca9bcd72d8ed8e2b158ac7c04f315bcc9c0d110b5bd0bb86a14e2b1d67afc3e8f2de53ef65d255c574374786985877b6d25671d076969487b797156509563875f857b9a4458835c8b9a9f9a7981a64e6d6c828e9f6f61687e9f9d579bbd9d7d4a7195a3a7ad89bbbab6a2cc46ab4f69810316bab6b487ba9070d1d082a4a8957bcf0298d7a2c0eccec1ab316e93699c94dd89d5dbd3d6d2d45cf6e2a5c4b8c39deef4dd40ac43258b09ec923754adeb07bd7b4f93908f1e1b485f048f91b970c4d2cfe666b00c09ad7aed43b70b84032ac17111bbf1b21135aba282ea3b90605dfa88363af212077fa4ede53496d643c41f986562c0a33954c811b09b631e85327c25c534d02b577b5e8376a1693aa5a3a61602c671f732a5c29b2e72f7814f9a06dbbf31f3ea213bd2a45f9f347d5aa425d62e5494ee25ab56f1dfa2a6cf72b5e5e2c4df245ec372560b87f03bbbcb0f572e2988b2737369b37eed168a2dd1a35bd176fb8d35c916e16132c34e6928f4bb7265d9bb264cb54f3e8a6bbfa35ecce697da4b60ab9b7e3b3bce90e66dd15ba72e1c66233960bba49edad7d231e0e9cb5ae74e0bea90f17ec19bb77e6db43768fba0fbce1e99f8947375f8638dbfaf0fe43b7c75d5278cf65a6554bf4e1878875e90de81e49fe35685b76a8d1a65a79e30985e02afa99c62080e43de8a14ebf7518db6a047e9861821b06c51f50a34905616e84b118a181e29d88618ac6ad185c721ebe071790f339e7507826da98a38e2d4ef85291436a17e08c4236b75f8d731d3957924afe22e2925402f6df71d7e1e8e497b68d88d8965e76a95e7f5022c7da9468ca676674649ea92697cccdb61c9c615228db8c95fd86a58278e649279b24466965903e0a5826a116de791fa271291aa9940ebe29667a77be57e2a448a669693798d2e9e86d3086b8a7a0bb49dae485a4967a69ab6dbab8299831323a27a815c64aa96b881a5ae5a27e32cafedda34f3229e1a1c18a572ab11c661a67aec525dbe8b2341ea7599bdf553a2c8f16fa7a6cb99d16d7ab8fa1023beaa1d18a1b2bb9abce0be898edca7b20a4ee5a2a2d8dc6d20be2b9557eaaeeaf7c1a0a6e9efdf668e59f01d7ebe9bd054b54a87dc22a0c6f7e7d02cc29c4e8baea9391a26639ebbbe87d7cabb62fb2b72b9ce9366c307fdf5eace6c2e34eccb1aeac062a2baa20577c72c23567ac17a0395fdb329b04c34cf1c808d3bca5cdf1e2ccb2b91e0f2c31d3ddea2b74d444efb871d5000fca2cbccddad96ed74a4aad71b32b3fdca7bd24fb3c1ed03343cbefd707af0777c771473c37be28ca1c9fda3ab25d74d87deb2c70d9270b9ee4b30c63fefcf8b47463bbb583646f9b35b7f96a9b39ada6dafaafd8a6ff8df2d29e0fee6de150afadb797a9861e59c8804b7d7681731b9e22e260bb6deddb9be76e7b9dba3f8d77b895fb4b2de69fab7ab5e3df413eabe4372b3fbde5d4236d35ea58074e35eb5cbf7e78ec299bf9b6dfc3f3fd3df176bb9e3ce5d9337f79cb533aef32c8a58b0ffaf3a2d7cab3fdf94d7daf925e7cb687b6dd91af77e61320e34eb73e37394e64ec5260fc86b63c86ad6e800ff49e018954bf2b39cd6217f45a06afb7c10e12b078ed331bfbaa97b60566c8777b9320f7c65640ce814f6bfed35fc9f276c2a9f17071378c9e0e71f74267c5b084b00b62db9298be0e46505f083c1efe092787c1f969d068a75b6187a818bec82d118b26d4220ab94844e1e590780e54a205c9d844330a31854584db14fbc7c29f8d30683244100d65a729e8d9718d498ce0ba6a78373896cf8989039e20bdd8bc4212528415449e2219c8c8df4131789a9b24188728c6375e4f7e07d45e185528454fe2b18d09b4e428b3584afa6d2f8a75bca3f1f258b73d26f295658ce51615c7c15aaaf296acb4221f99b848393ed186b454232ed918494a22127e979c6103a3e9304886f093746ce5157919475f9e1198a814e63325794e69120e84bcb366266b88ab47a6329ddc4463285d29c4ffe9739ffceca73fff09d0800a74a0042da8410f8ad0842a74a10c6da843541f0ad1883e347bf994a845271a831364740417eda84729d0810668f4a324ed2851325ad192aa74a09918694a570ad37ebe64027d8ca94d6b36858d8af4a63c0da80b9ef0d29e0a75a8442daa518f8ad4a426a200003b, 'Onco'),
(2345, 'Thathsarani', 0x4749463839614a015c00f00000ffffff0000002c000000004a015c000002fe848fa96be17f6092ac39f5f29d3a76ae6d0815626248799919b0a5b5c2ef28aa241a03f3ec7efae9ab0887c4a20cd8021153c79c0dc9fca158cf24cd8ab356a9a09d2fcbbddeb2d86fb06b2e3b8decf6d0ab852d6bcd28dc8e0bf3e475ba141ff79736b627d5a306d6b4c59068a8e8061989a61656015878e7d7a8b2785575a9193af528b8e6280695475af889d42909db0657c9288a39687b767a8ba8cb7b48986a0ada3b5afa3a39861ccb2c34abf4963b8c1bb8c9770c5d4a4cab2ddc5a2dfd1d5c6ca9baabdb9c3ec9995d0e6edcc9fb4bcadefd0e08ecddf77e28ae8fbda0d138750403a6e1c6cd1a4079befed553380f558e4cd3ee09a3b8ecdb43fe7405d33df314cd62c581c9442d1bb7adddbe78e6eab124f3328ac66bac3a36fbe8b296c894006782ec49b325bd6b3e29e25bb78f245089ca86daf47850a5c19de19c427418149e55694aaf8af447ce6951ac4f6f46fde92edfd7ad5acf55f47992eb3faffd92cee5686fa3a9b2b17012d5a9b6ee52ba6ce1162e1936af54a3d432aecc2a93af24bfa7d22216ccf0ed61c512139a63cc0fa9bdae780592953cf96ccea98145673e3af86255b48f170aadbc8a4ce29a9c95a2eeabfa2febcbae1bb6f50dd938ecb1136ff3d4bdbbf4e7d3bfdd508e4c9b734cb9a16317e3b9da74f3e3b3a16f0fc4dc717536d7fd78263f9e18ec885e97d706fd1e6563b1f7fea9af37d21e7a8b39b71f53266d56df810646071f66ba9de7ce47bcfd37c778080d081f72da25d75d82dd31a7df87b9c1342276e2a94761484d65979f726411e69d613112675b83c59158a389d32596a22cc1e136dc820e8e645c5cdfcd16de8e21b678647cfe9dc85f8fcefc885d9219be48208f1c82279c784b621822697bf5a7a59415aeb81a93cfb9a8d98c1bba09a26c22e6a8e4933ba268e6901766e7a191f415599b91add1d9e679184509e5527946e88a546a96c7e67c80be19519c4d320916843a4988d7a237ee6965667e4efae795737a2927a67631a8a3311a7a3a159ac23dba9677a54a6a2aad862ab8ab9365a61725ac2f81da65961ac278fe2b9bba963869af62b6cae998c20eeb2898cab2956c87c6f24ae6977c5273a8a264e2296c80150eaaa990d964cb2590a85e6a6d93cfba376eb0d39a1b12bacc52a56d9b7dc63b6fa1fb86cb5ba213de4b25bddfe68a2da90e33bc30c1590ef9ae7a06778ab085d5467cadad0fe32a2ac077d9d8d9aae90efaeab4d4b22872adaf29c82e92c5ba0a2eb7844a2cedc5d2aa8cef94fc52cc9d1e1f771c6a81303a3b32b4671d5c6ec202724c6499c80e1df5b237db0c5ac08c6a2caeca3512ebeeb6524f8ca0d856e3176fa6fb6ebd22d3b0f66c99ba257bec2fd5edca9774b3031b2d1dcdbf7afdf5c64557dd70dd86870c75c0f65dedabc577dadb34d769b6fe0cf4cfebda2d73d87e7b3bb8da84b2dd68d73c3b7d2e8d2707caa1d0100fae38d635378ee8e3a2672c2b90569f4e2996f0cecd7ade0233aef5a64b631c79ed55ce8cf8cbfd824c34f27c938c34ab0aeb7c7cf1a14f9e38a45133bf7cf39ae35ce9deb0774dbdc2a34b3e2be537e2dd7dfb77072dbeaaa3f90e3a2590bf4d7abea6afbdbf5bdcbf6f39c6c9cf3cfc8bd5f07646bbeba52f7b2e8b14cc3057abde49ef7759a39ff0b8e6364fc10d30fd0b978c8e952ad148b057037c500151e69ff319cf7cce231cddb8a73ac48d307e6933d909699432af6d30481f2c500fc7b63b41e1f07525c4910787f8371de6cf67fafa5c0775f7c3c5550c75df9353fef00c8841e2e10f7db653dfdc9417c307aeae85ad3bd5ebae88c224aa50815d6460e59a08c2206ec6523fac1cf8a627bb0c2e6a87b7bb61ee801845d76d2e8450f3dc11e596c335da8f656e5c1ffc7e12b30892d177523ca305b1d8362d6a7089710b2410b3154617ce5080359cdf04eba797ea6d71854f1b25eea67638efb18f84a524a01331193a3de6898f5e7c25d9dcf4af4692b29036bc651ac9b54a36566f968e0c602ac528c3494eb092bebae3d3cad7ca042e127baef4232cff9739660eb373c53c24b06667bd6d2eb09bc6a4621c3d793622d6d284ed44640ab569a5d2c9cd97248ba460468936629a1277e7d4a59978294c7e82f27263ace2f8fe8e263e342211999be4e2321fa950aa85128069e45c0b0de9c389deafa2acd4273c0b07438646d3a1652ce214c997474dee91931cdca7377fe94f114a939602b5a539eb85ce64aab38dec3ce437a129cb4706949c03f5634165ba4b9af2d09d21fda310ff484d6b66d58a973ce648676a5116b2547be27ca6fbc2a95479f6949e3fedcd3dd3994ffdd9b49e473dab24c73a4d4186a9ab220d2a499529d6b2deb49f10fce74e69b8562356f5a90884ebcc4c4ad5f1d5b16c0d15e7523f5acec502d5a052426851ab5ad78da235809775284825db57cef6c8b387fda203db27dabb5a56ad4cf5a966ddaa46c0e976b7bcedad6f7f0bdce00a77b8c42dae718f7f8bdce42a77b9cc6dae739f0bdde84a77bad4adae75af7b5048d20111d8edae77371981f062c103e1fdae79cffb9f16a0270e49506f03d00bdff84a66bde47d6f7b5529dffcead71218e86f7bfbbbdf000bf80d130888200a3ce0042bf8bde565b00e46e0e06c2e78c2dfedc55f864ae10c6b78c31ceeb0873f0ce210abac00003b, 'Breast');

-- --------------------------------------------------------

--
-- Table structure for table `ward`
--

CREATE TABLE `ward` (
  `Ward_No` varchar(10) NOT NULL,
  `Ward_Name` varchar(30) DEFAULT NULL,
  `Mobile_No` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`D_Name`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ward`
--
ALTER TABLE `ward`
  ADD PRIMARY KEY (`Ward_No`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
